from django import forms
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from .models import request_rental


class DateInput(forms.DateInput):
    input_type = 'date'

class DateForm(forms.Form):
    date_field = forms.DateField(widget=DateInput)

