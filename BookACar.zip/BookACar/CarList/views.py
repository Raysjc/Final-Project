from django.shortcuts import render, redirect
from django.http import HttpResponse, JsonResponse, Http404, HttpResponseForbidden
from django.views.generic import ListView, DetailView, CreateView, FormView
from .models import Car, request_rental
from django.contrib import messages
from .forms import DateForm
from django import forms






# Create your views here.
def home(request):
    return render(request, 'views/index.html')

def guide(request):
    return render(request, 'views/list_your_car.html')

def login(request):
    return render(request, 'users/register.html')


def car_list(request):
    qs = Car.objects.all()
    zip_query = request.GET.get('zip')

    if zip_query != '' and zip_query is not None:
        qs = qs.filter(zip_code__icontains=zip_query)

    context = {
        'queryset': qs
    }
    return render(request, 'views/car_list.html', context)

# class DateInput(forms.DateInput):
#     input_type = 'date'

# class DateForm(forms.Form):
#     date_field = forms.DateField(widget=DateInput)
#     model = request_rental
#     fields = ['start_date', 'end_date']
#     def form_valid(self, form):
#         form.instance.author = self.request.user
#         return super().form_valid(form)

class CarDetailView(DetailView):
    model = Car
    template_name = 'views/car_detail.html'




class CarCreateView(CreateView):
    model = Car
    template_name = 'views/car_create.html'
    fields = ['brand', 'model', 'year', 'price','image', 'description', 'zip_code']

    def form_valid(self, form):
        form.instance.host = self.request.user
        return super().form_valid(form)


def car_request(request):
    template_name = 'views/car_request.html'
    if request.method == 'POST':
        form = DateForm(request.POST)
        if form.is_valid():
            form.save()
            start_date = form.cleaned_data.get('start_date')
            end_date = form.cleaned_data.get('end_date')
            return redirect('car_list')
    else:
        form = DateForm()
    return render(request, 'views/car_request.html', {'form': form})   
