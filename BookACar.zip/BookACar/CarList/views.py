from django.shortcuts import render
from django.http import HttpResponse, JsonResponse, Http404
from django.views.generic import ListView, DetailView, CreateView
from .models import Car


# Create your views here.
def home(request):
    return render(request, 'views/index.html')

def guide(request):
    return render(request, 'views/list_your_car.html')

def login(request):
    return render(request, 'users/register.html')

class CarListView(ListView):
    model = Car
    template_name = 'views/car_list.html'
    ordering = ['-date_posted']

class CarDetailView(DetailView):
    model = Car


class CarCreateView(CreateView):
    model = Car
    fields = ['brand', 'model', 'year',]

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)


