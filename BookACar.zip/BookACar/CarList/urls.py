from django.urls import path
from . import views 
from django.contrib.auth import views as auth_views
from users import views as user_views
from .views import CarListView, CarDetailView, CarCreateView 

# add object to map urls with actions in views.py

urlpatterns = [
    path('', views.home, name='home'),
    path('guide', views.guide, name='guide'),
    path('register/', user_views.register, name='register'),
    path('car_list', CarListView.as_view(), name='car-list'),
    path('car/<int:pk>', CarDetailView.as_view(), name='car-detail'),
    path('car/new/', CarCreateView.as_view(), name='car-create'),
]