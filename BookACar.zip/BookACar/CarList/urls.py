from django.urls import path
from . import views 
from django.contrib.auth import views as auth_views
from users import views as user_views
from .views import CarDetailView, CarCreateView 

# add object to map urls with actions in views.py

urlpatterns = [
    path('', views.home, name='home'),
    path('guide', views.guide, name='guide'),
    path('register/', user_views.register, name='register'),
    path('car_request/', views.car_request, name='car_request'),
    path('car_list', views.car_list, name='car_list'),
    path('car/<int:pk>', CarDetailView.as_view(), name='car-detail'),
    path('car/new/', CarCreateView.as_view(), name='car-create'),
]