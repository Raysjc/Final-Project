from django.apps import AppConfig


class CarlistConfig(AppConfig):
    name = 'CarList'
