from django.db import models
from django.utils import  timezone
from django.contrib.auth.models import  User
from django.urls import reverse

# Create your models here.
class Car(models.Model):
    date_posted = models.DateTimeField(default=timezone.now)
    brand = models.CharField(max_length = 25)
    model = models.CharField(max_length = 25)
    year = models.IntegerField()
    price = models.FloatField()
    image = models.ImageField(upload_to='images', default='car-default.png')
    description = models.CharField(max_length = 100, default="")
    zip_code = models.CharField(max_length = 5, default="00000")
    host = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)

    def __str__(self):
        return self.brand

    def get_absolute_url(self):
        return reverse('car-detail', kwargs={'pk': self.pk})
    
class request_rental(models.Model):
    start_date = models.DateField()
    end_date = models.DateField()
    host = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True)